export default function RootLayout({ children }) {
  return <>{children}</>;
}